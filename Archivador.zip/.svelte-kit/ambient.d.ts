
// this file is generated — do not edit it


/// <reference types="@sveltejs/kit" />

/**
 * This module provides access to environment variables that are injected _statically_ into your bundle at build time and are limited to _private_ access.
 * 
 * |         | Runtime                                                                    | Build time                                                               |
 * | ------- | -------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
 * | Private | [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private) | [`$env/static/private`](https://svelte.dev/docs/kit/$env-static-private) |
 * | Public  | [`$env/dynamic/public`](https://svelte.dev/docs/kit/$env-dynamic-public)   | [`$env/static/public`](https://svelte.dev/docs/kit/$env-static-public)   |
 * 
 * Static environment variables are [loaded by Vite](https://vitejs.dev/guide/env-and-mode.html#env-files) from `.env` files and `process.env` at build time and then statically injected into your bundle at build time, enabling optimisations like dead code elimination.
 * 
 * **_Private_ access:**
 * 
 * - This module cannot be imported into client-side code
 * - This module only includes variables that _do not_ begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) _and do_ start with [`config.kit.env.privatePrefix`](https://svelte.dev/docs/kit/configuration#env) (if configured)
 * 
 * For example, given the following build time environment:
 * 
 * ```env
 * ENVIRONMENT=production
 * PUBLIC_BASE_URL=http://site.com
 * ```
 * 
 * With the default `publicPrefix` and `privatePrefix`:
 * 
 * ```ts
 * import { ENVIRONMENT, PUBLIC_BASE_URL } from '$env/static/private';
 * 
 * console.log(ENVIRONMENT); // => "production"
 * console.log(PUBLIC_BASE_URL); // => throws error during build
 * ```
 * 
 * The above values will be the same _even if_ different values for `ENVIRONMENT` or `PUBLIC_BASE_URL` are set at runtime, as they are statically replaced in your code with their build time values.
 */
declare module '$env/static/private' {
	export const STORAGE_MODE: string;
	export const STRAPI_API_TOKEN: string;
	export const STRAPI_API_URL: string;
	export const STRAPI_ENDPOINT: string;
	export const TMDB_API_TOKEN: string;
	export const RECOSERVICIO_SERVERNODERUPA: string;
	export const autogestion_database_properties_rupabk_jpa_showSql: string;
	export const ijd_database_testdb_hibernate_use_sql_comments: string;
	export const webappsiceep_webxml_pathKeystore: string;
	export const RECOSERVICIO_SERVERNODE: string;
	export const autogestion_log4j_logspath: string;
	export const LESSOPEN: string;
	export const KDE_FULL_SESSION: string;
	export const sap_database_rupabk_database_username: string;
	export const autogestion_database_properties_testdb_jpa_showSql: string;
	export const sap_gdebaclient_properties_gdebaclient_cuilMalvinas: string;
	export const ijd_gdebaclient_generaciondocumentos_uri: string;
	export const sap_webxml_maxSessionsUsers: string;
	export const sap_database_properties_rupabk_connection_acquireIncrement: string;
	export const LANGUAGE: string;
	export const webappsiceep_webxml_dbUrlRUPA: string;
	export const sap_ipscontexto_properties_sap_tag: string;
	export const sap_ipscontexto_mail_subidaddjjfirmada: string;
	export const sap_database_testdb_database_username: string;
	export const sap_webxml_pathKeystore: string;
	export const RECOSERVICIO_WEBDOC_SERVICIO_PROD: string;
	export const sap_database_properties_testdb_connection_acquireIncrement: string;
	export const USER: string;
	export const mailtask_path: string;
	export const PAM_KWALLET5_LOGIN: string;
	export const ijd_gdebaclient_usuario_uri: string;
	export const autogestion_database_properties_rupabk_connection_checkoutTimeout: string;
	export const webappsiceep_webxml_dbMinCon: string;
	export const npm_config_user_agent: string;
	export const autogestion_gdebaclient_properties_gdebaclient_generartareagedo_uri: string;
	export const IPS_DATA_SOURCE_RUPA_USER: string;
	export const XDG_SEAT: string;
	export const ijd_database_rupabk_database_password: string;
	export const autogestion_database_properties_testdb_connection_checkoutTimeout: string;
	export const ijd_gdebaclient_token: string;
	export const JAVA_TOOL_OPTIONS: string;
	export const autogestion_gdebaclient_properties_gdebaclient_transaccion_uri: string;
	export const SSH_AGENT_PID: string;
	export const webappsiceep_webxml_dbIPSMinCon: string;
	export const webappsiceep_webxml_dbIPSUrl: string;
	export const XDG_SESSION_TYPE: string;
	export const autogestion_webxml_passwdSmtpServerExterno: string;
	export const GIT_ASKPASS: string;
	export const autogestion_gdebaclient_properties_gdebaclient_documentosoficiales_uri: string;
	export const autogestion_recibohaberes_properties_recibohaberes_timeout: string;
	export const ijd_database_testdb_database_password: string;
	export const webappsiceep_webxml_dbMaxCon: string;
	export const ijd_WebFileUtils_host: string;
	export const npm_node_execpath: string;
	export const ijd_database_rupabk_database_url: string;
	export const XCURSOR_SIZE: string;
	export const sap_gdebaclient_properties_gdebaclient_paseexpediente_uri: string;
	export const IPS_DATA_SOURCE_RUPA_URL: string;
	export const SHLVL: string;
	export const PROBANDO: string;
	export const npm_config_noproxy: string;
	export const ijd_database_testdb_database_url: string;
	export const gid: string;
	export const autogestion_webxml_maxSessionsUsers: string;
	export const ANTIGRAVITY_CLI_ALIAS: string;
	export const HOME: string;
	export const CHROME_DESKTOP: string;
	export const sap_ipscontexto_properties_ipscore_tag: string;
	export const autogestion_database_properties_rupabk_connection_acquireIncrement: string;
	export const webappsiceep_webxml_dbIPSMaxCon: string;
	export const sap_glpiclient_properties_glpiclient_token: string;
	export const webappsiceep_RUPA_DB_PASS: string;
	export const KDE_APPLICATIONS_AS_SCOPE: string;
	export const sap_gdebaclient_properties_gdebaclient_generacionexpediente_uri: string;
	export const TERM_PROGRAM_VERSION: string;
	export const DESKTOP_SESSION: string;
	export const sap_clienteeducacion_properties_clienteeducacion_uri: string;
	export const autogestion_database_properties_testdb_connection_acquireIncrement: string;
	export const sap_database_properties_rupabk_database_password: string;
	export const computos_log4j: string;
	export const sap_gdeba_properties_usuariogdeba_deptonotif_cuil: string;
	export const NVM_BIN: string;
	export const npm_package_json: string;
	export const computos_beans_db_user_ipsol: string;
	export const NVM_INC: string;
	export const ijd_database_rupabk_hibernate_show_sql: string;
	export const sap_database_properties_testdb_database_password: string;
	export const ijd_gdebaclient_transaccion_uri: string;
	export const ijd_database_rupabk_connection_minPoolSize: string;
	export const sap_database_properties_rupabk_database_url: string;
	export const GTK_RC_FILES: string;
	export const ijd_gdebaclient_generartareagedo_uri: string;
	export const XDG_SEAT_PATH: string;
	export const ijd_database_testdb_hibernate_show_sql: string;
	export const RECOSERVICIO_DB_PASS: string;
	export const KDE_SESSION_VERSION: string;
	export const sap_database_properties_rupabk_hibernate_use_jdbc_metadata_defaults: string;
	export const sap_gdebaclient_properties_gdebaclient_consultadocumento_uri: string;
	export const VSCODE_GIT_ASKPASS_MAIN: string;
	export const ijd_database_testdb_connection_minPoolSize: string;
	export const ijd_database_rupabk_connection_maxIdleTime: string;
	export const webappsiceep_webxml_urlHostSAP: string;
	export const entorno: string;
	export const VSCODE_GIT_ASKPASS_NODE: string;
	export const ijd_gdebaclient_documentosoficiales_uri: string;
	export const git_pass: string;
	export const MANAGERPID: string;
	export const autogestion_gdebaclient_properties_gdebaclient_paseexpediente_uri: string;
	export const uid: string;
	export const ruta_contexto: string;
	export const sap_database_properties_testdb_hibernate_use_jdbc_metadata_defaults: string;
	export const sap_database_properties_testdb_database_url: string;
	export const npm_config_userconfig: string;
	export const npm_config_local_prefix: string;
	export const ijd_database_testdb_connection_maxIdleTime: string;
	export const SYSTEMD_EXEC_PID: string;
	export const sap_ipscontexto_properties_ipscontexto_ambiente: string;
	export const VSCODE_PYTHON_AUTOACTIVATE_GUARD: string;
	export const webappsiceep_webxml_dbIPSPasswd: string;
	export const GSM_SKIP_SSH_AGENT_WORKAROUND: string;
	export const ijd_database_rupabk_connection_maxPoolSize: string;
	export const ijd_WebFileUtils_protocol: string;
	export const DBUS_SESSION_BUS_ADDRESS: string;
	export const npm_config_engine_strict: string;
	export const COLORTERM: string;
	export const autogestion_gdeba_properties_usuariogdeba_deptonotif_cuil: string;
	export const autogestion_database_properties_rupabk_database_password: string;
	export const ijd_database_testdb_connection_maxPoolSize: string;
	export const sap_database_properties_rupabk_hibernate_show_sql: string;
	export const autogestion_gdebaclient_properties_gdebaclient_generacionexpediente_uri: string;
	export const COLOR: string;
	export const ijd_database_rupabk_hibernate_format_sql: string;
	export const sap_database_properties_testdb_hibernate_show_sql: string;
	export const NVM_DIR: string;
	export const sap_database_properties_rupabk_connection_minPoolSize: string;
	export const ijd_encrypted_key: string;
	export const DEBUGINFOD_URLS: string;
	export const autogestion_database_properties_testdb_database_password: string;
	export const ijd_WebFileUtils_pathname: string;
	export const MANDATORY_PATH: string;
	export const sap_database_properties_testdb_connection_minPoolSize: string;
	export const IM_CONFIG_PHASE: string;
	export const autogestion_gdebaclient_properties_gdebaclient_consultadocumento_uri: string;
	export const sap_gdebaclient_properties_gdebaclient_cuilRegEspeciales: string;
	export const webappsiceep_RUPA_DB_USER: string;
	export const autogestion_database_properties_rupabk_database_url: string;
	export const ijd_database_testdb_hibernate_format_sql: string;
	export const sap_database_properties_rupabk_connection_maxIdleTime: string;
	export const computos_beans_db_user_rupa: string;
	export const GTK_IM_MODULE: string;
	export const sap_database_properties_testdb_connection_maxIdleTime: string;
	export const sap_database_properties_rupabk_connection_maxPoolSize: string;
	export const LOGNAME: string;
	export const autogestion_database_properties_testdb_database_url: string;
	export const computos_beans_db_password_ipsol: string;
	export const webappsiceep_RUPA_DB_URL: string;
	export const app_log4j_logspath: string;
	export const computos_beans_db_minCount_ipsol: string;
	export const ijd_gdebaclient_paseexpediente_uri: string;
	export const sap_webxml_isSmtpServerTest: string;
	export const autogestion_ipscontexto_properties_ipscontexto_ambiente: string;
	export const sap_database_properties_testdb_connection_maxPoolSize: string;
	export const QT_AUTO_SCREEN_SCALE_FACTOR: string;
	export const JOURNAL_STREAM: string;
	export const _: string;
	export const npm_config_prefix: string;
	export const npm_config_npm_version: string;
	export const autogestion_database_properties_rupabk_hibernate_show_sql: string;
	export const MEMORY_PRESSURE_WATCH: string;
	export const sap_database_properties_rupabk_hibernate_format_sql: string;
	export const ijd_provincia_uri: string;
	export const XDG_SESSION_CLASS: string;
	export const computos_beans_db_url_ipsol: string;
	export const DEFAULTS_PATH: string;
	export const ijd_log4j_logspath: string;
	export const RECOSERVICIO_DB_USER: string;
	export const ijd_gdebaclient_generacionexpediente_uri: string;
	export const autogestion_database_properties_rupabk_connection_minPoolSize: string;
	export const sap_database_properties_testdb_hibernate_format_sql: string;
	export const TERM: string;
	export const computos_beans_db_maxCount_ipsol: string;
	export const XDG_SESSION_ID: string;
	export const autogestion_database_properties_testdb_hibernate_show_sql: string;
	export const ijd_database_rupabk_connection_breakAfterAcquireFailure: string;
	export const git_user: string;
	export const npm_config_cache: string;
	export const autogestion_database_properties_testdb_connection_minPoolSize: string;
	export const ijd_database_testdb_connection_breakAfterAcquireFailure: string;
	export const FC_FONTATIONS: string;
	export const autogestion_database_properties_rupabk_connection_maxIdleTime: string;
	export const ijd_gdebaclient_consultadocumento_uri: string;
	export const sap_clienteeducacion_properties_clienteeducacionperiodo_uri: string;
	export const GTK2_RC_FILES: string;
	export const autogestion_database_properties_rupabk_connection_maxPoolSize: string;
	export const ijd_ipscontexto_webijd_observaciontramite_emp40101_mail: string;
	export const autogestion_database_properties_testdb_connection_maxIdleTime: string;
	export const sap_database_rupabk_database_password: string;
	export const ijd_gdebaclient_cuil_tareafirma: string;
	export const sap_ipscontexto_properties_mick_tag: string;
	export const npm_config_node_gyp: string;
	export const PATH: string;
	export const SESSION_MANAGER: string;
	export const ijd_webxml_passwdSmtpServerExterno: string;
	export const IPS_DATA_SOURCE_PASSWORD: string;
	export const computos_beans_db_password_rupa: string;
	export const autogestion_database_properties_testdb_connection_maxPoolSize: string;
	export const INVOCATION_ID: string;
	export const sap_database_testdb_database_password: string;
	export const sap_ipscontexto_properties_gdeba_tag: string;
	export const autogestion_webxml_isSmtpServerTest: string;
	export const NODE: string;
	export const npm_package_name: string;
	export const ijd_WSResolucionGDEBA_host: string;
	export const XDG_SESSION_PATH: string;
	export const ijd_ipscontexto_ambiente: string;
	export const sap_ipscontexto_properties_ipscontexto_mail: string;
	export const autogestion_gdebaclient_properties_gdebaclient_cuiltramitesfiscalia: string;
	export const sap_database_rupabk_database_url: string;
	export const PATH_WEBAPP_TOMCAT: string;
	export const computos_beans_db_minCount_rupa: string;
	export const XDG_RUNTIME_DIR: string;
	export const XCURSOR_THEME: string;
	export const GDK_BACKEND: string;
	export const ICEAUTHORITY: string;
	export const computos_beans_db_url_rupa: string;
	export const sap_gdebaclient_properties_gdebaclient_cuilMagisterio: string;
	export const DISPLAY: string;
	export const ijd_database_rupabk_database_username: string;
	export const sap_database_testdb_database_url: string;
	export const sap_gdebaclient_properties_gdebaclient_consultaexpediente_uri: string;
	export const computos_beans_db_maxCount_rupa: string;
	export const RECOSERVICIOS_RUPA_minCount: string;
	export const LANG: string;
	export const XDG_CURRENT_DESKTOP: string;
	export const autogestion_gdeba_properties_usuariogdeba_notificaciones_cuil: string;
	export const ijd_database_testdb_database_username: string;
	export const webappsiceep_webxml_dbRUPAPass: string;
	export const RECOSERVICIOS_IPSOL_minCount: string;
	export const XMODIFIERS: string;
	export const XDG_SESSION_DESKTOP: string;
	export const XAUTHORITY: string;
	export const IPS_DATA_SOURCE_USER: string;
	export const LS_COLORS: string;
	export const VSCODE_GIT_IPC_HANDLE: string;
	export const TERM_PROGRAM: string;
	export const npm_lifecycle_script: string;
	export const SSH_AUTH_SOCK: string;
	export const RECOSERVICIOS_RUPA_maxCount: string;
	export const RECOSERVICIO_DB_PASS_RUPA: string;
	export const autogestion_WebFileUtils_host: string;
	export const sap_gdebaclient_properties_gdebaclient_cuilMunicipal: string;
	export const webijd_log4j_logger_org_hibernate_SQL: string;
	export const SHELL: string;
	export const sap_webfiles_properties_webfiles_url: string;
	export const autogestion_ipscontexto_properties_ipscontexto_mail: string;
	export const sap_gdebaclient_properties_gdebaclient_bloqueoexpediente_uri: string;
	export const sap_database_properties_rupabk_database_username: string;
	export const RECOSERVICIO_WEBDOC_SERVICIO: string;
	export const IPS_DATA_SOURCE_URL: string;
	export const WEBXML_smtpMailServer: string;
	export const RECOSERVICIOS_IPSOL_maxCount: string;
	export const npm_package_version: string;
	export const npm_lifecycle_event: string;
	export const QT_ACCESSIBILITY: string;
	export const sap_ipscontexto_properties_glpi_tag: string;
	export const sap_database_properties_testdb_database_username: string;
	export const MI_IPS_IPSCOREAPI_LOGIN: string;
	export const autogestion_gdebaclient_properties_gdebaclient_cuilMagisterio: string;
	export const ijd_gdebaclient_cuiltramitesfiscalia: string;
	export const autogestion_gdebaclient_properties_gdebaclient_consultaexpediente_uri: string;
	export const ijd_WSResolucionGDEBA_protocol: string;
	export const LESSCLOSE: string;
	export const sap_gdebaclient_properties_gdebaclient_generaciondocumentos_uri: string;
	export const WEBXML_mailFromAdress: string;
	export const ijd_database_rupabk_jpa_showSql: string;
	export const sap_gdebaclient_properties_gdebaclient_usuario_uri: string;
	export const sap_ipscontexto_mail_normativa: string;
	export const GPG_AGENT_INFO: string;
	export const webappsiceep_webxml_smtpMailServer: string;
	export const sap_recibohaberes_properties_recibohaberes_url: string;
	export const autogestion_gdebaclient_properties_gdebaclient_cuilMunicipal: string;
	export const sap_gdebaclient_properties_gdebaclient_token: string;
	export const sap_gdeba_properties_usuariogdeba_rodolfo_cuil: string;
	export const ijd_encrypted_vector: string;
	export const ijd_provincia_token: string;
	export const ijd_database_testdb_jpa_showSql: string;
	export const ijd_WSResolucionGDEBA_pathname: string;
	export const ijd_webxml_session_timeout: string;
	export const sap_gdebaclient_properties_gdebaclient_cuil: string;
	export const autogestion_database_properties_rupabk_database_username: string;
	export const webappsiceep_log4j_logspath: string;
	export const webappsiceep_webxml_dbRUPAUser: string;
	export const sap_ipscontexto_properties_educacion_tag: string;
	export const sap_webxml_sessiontimeout: string;
	export const VSCODE_GIT_ASKPASS_EXTRA_ARGS: string;
	export const autogestion_gdebaclient_properties_gdebaclient_bloqueoexpediente_uri: string;
	export const QT_IM_MODULE: string;
	export const XDG_VTNR: string;
	export const ijd_database_rupabk_connection_checkoutTimeout: string;
	export const sap_gdebaclient_properties_gdebaclient_cuilGeneral: string;
	export const autogestion_webfiles_properties_webfiles_url: string;
	export const npm_config_globalconfig: string;
	export const npm_config_init_module: string;
	export const webappsiceep_webxml_mailFromAdress: string;
	export const WEBXML_sessionTimeout: string;
	export const PWD: string;
	export const ijd_database_testdb_connection_checkoutTimeout: string;
	export const autogestion_database_properties_testdb_database_username: string;
	export const ijd_ipscontexto_mail: string;
	export const autogestion_WebFileUtils_protocol: string;
	export const npm_execpath: string;
	export const RECOSERVICIO_DB_USER_RUPA: string;
	export const sap_database_properties_rupabk_jpa_showSql: string;
	export const XDG_CONFIG_DIRS: string;
	export const sap_log4j_logspath: string;
	export const CLUTTER_IM_MODULE: string;
	export const webappsiceep_webxml_dbIPSUser: string;
	export const NVM_CD_FLAGS: string;
	export const autogestion_gdebaclient_properties_gdebaclient_generaciondocumentos_uri: string;
	export const XDG_DATA_DIRS: string;
	export const sap_glpiclient_properties_glpiclient_url: string;
	export const npm_config_global_prefix: string;
	export const RECOSERVICIO_SERVERDB: string;
	export const sap_database_properties_rupabk_connection_maxConnectionAge: string;
	export const sap_database_properties_testdb_jpa_showSql: string;
	export const QTWEBENGINE_DICTIONARIES_PATH: string;
	export const autogestion_gdebaclient_properties_gdebaclient_usuario_uri: string;
	export const ijd_gdebaclient_consultaexpediente_uri: string;
	export const RECOSERVICIO_SERVERDBRUPA: string;
	export const npm_command: string;
	export const autogestion_WebFileUtils_pathname: string;
	export const autogestion_gdebaclient_properties_gdebaclient_token: string;
	export const autogestion_recibohaberes_properties_recibohaberes_url: string;
	export const sap_database_properties_testdb_connection_maxConnectionAge: string;
	export const ijd_database_rupabk_connection_acquireIncrement: string;
	export const KDE_SESSION_UID: string;
	export const autogestion_gdeba_properties_usuariogdeba_rodolfo_cuil: string;
	export const RECOSERVICIO_DB_URL_RUPA: string;
	export const sap_database_properties_rupabk_connection_checkoutTimeout: string;
	export const sap_gdebaclient_properties_gdebaclient_generartareagedo_uri: string;
	export const MEMORY_PRESSURE_WRITE: string;
	export const autogestion_webxml_sessiontimeout: string;
	export const autogestion_gdebaclient_properties_gdebaclient_cuilGeneral: string;
	export const sap_gdebaclient_properties_gdebaclient_transaccion_uri: string;
	export const ijd_database_testdb_connection_acquireIncrement: string;
	export const sap_database_properties_testdb_connection_checkoutTimeout: string;
	export const sap_recibohaberes_properties_recibohaberes_timeout: string;
	export const sap_gdebaclient_properties_gdebaclient_documentosoficiales_uri: string;
	export const CATALINA_OPTS: string;
	export const sap_webxml_passwdSmtpServerExterno: string;
	export const ijd_webxml_isSmtpServerTest: string;
	export const ijd_gdebaclient_bloqueoexpediente_uri: string;
	export const ijd_database_rupabk_hibernate_use_sql_comments: string;
	export const IPS_DATA_SOURCE_RUPA_PASSWORD: string;
	export const INIT_CWD: string;
	export const EDITOR: string;
	export const NODE_ENV: string;
}

/**
 * This module provides access to environment variables that are injected _statically_ into your bundle at build time and are _publicly_ accessible.
 * 
 * |         | Runtime                                                                    | Build time                                                               |
 * | ------- | -------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
 * | Private | [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private) | [`$env/static/private`](https://svelte.dev/docs/kit/$env-static-private) |
 * | Public  | [`$env/dynamic/public`](https://svelte.dev/docs/kit/$env-dynamic-public)   | [`$env/static/public`](https://svelte.dev/docs/kit/$env-static-public)   |
 * 
 * Static environment variables are [loaded by Vite](https://vitejs.dev/guide/env-and-mode.html#env-files) from `.env` files and `process.env` at build time and then statically injected into your bundle at build time, enabling optimisations like dead code elimination.
 * 
 * **_Public_ access:**
 * 
 * - This module _can_ be imported into client-side code
 * - **Only** variables that begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) (which defaults to `PUBLIC_`) are included
 * 
 * For example, given the following build time environment:
 * 
 * ```env
 * ENVIRONMENT=production
 * PUBLIC_BASE_URL=http://site.com
 * ```
 * 
 * With the default `publicPrefix` and `privatePrefix`:
 * 
 * ```ts
 * import { ENVIRONMENT, PUBLIC_BASE_URL } from '$env/static/public';
 * 
 * console.log(ENVIRONMENT); // => throws error during build
 * console.log(PUBLIC_BASE_URL); // => "http://site.com"
 * ```
 * 
 * The above values will be the same _even if_ different values for `ENVIRONMENT` or `PUBLIC_BASE_URL` are set at runtime, as they are statically replaced in your code with their build time values.
 */
declare module '$env/static/public' {
	
}

/**
 * This module provides access to environment variables set _dynamically_ at runtime and that are limited to _private_ access.
 * 
 * |         | Runtime                                                                    | Build time                                                               |
 * | ------- | -------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
 * | Private | [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private) | [`$env/static/private`](https://svelte.dev/docs/kit/$env-static-private) |
 * | Public  | [`$env/dynamic/public`](https://svelte.dev/docs/kit/$env-dynamic-public)   | [`$env/static/public`](https://svelte.dev/docs/kit/$env-static-public)   |
 * 
 * Dynamic environment variables are defined by the platform you're running on. For example if you're using [`adapter-node`](https://github.com/sveltejs/kit/tree/main/packages/adapter-node) (or running [`vite preview`](https://svelte.dev/docs/kit/cli)), this is equivalent to `process.env`.
 * 
 * **_Private_ access:**
 * 
 * - This module cannot be imported into client-side code
 * - This module includes variables that _do not_ begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) _and do_ start with [`config.kit.env.privatePrefix`](https://svelte.dev/docs/kit/configuration#env) (if configured)
 * 
 * > [!NOTE] In `dev`, `$env/dynamic` includes environment variables from `.env`. In `prod`, this behavior will depend on your adapter.
 * 
 * > [!NOTE] To get correct types, environment variables referenced in your code should be declared (for example in an `.env` file), even if they don't have a value until the app is deployed:
 * >
 * > ```env
 * > MY_FEATURE_FLAG=
 * > ```
 * >
 * > You can override `.env` values from the command line like so:
 * >
 * > ```sh
 * > MY_FEATURE_FLAG="enabled" npm run dev
 * > ```
 * 
 * For example, given the following runtime environment:
 * 
 * ```env
 * ENVIRONMENT=production
 * PUBLIC_BASE_URL=http://site.com
 * ```
 * 
 * With the default `publicPrefix` and `privatePrefix`:
 * 
 * ```ts
 * import { env } from '$env/dynamic/private';
 * 
 * console.log(env.ENVIRONMENT); // => "production"
 * console.log(env.PUBLIC_BASE_URL); // => undefined
 * ```
 */
declare module '$env/dynamic/private' {
	export const env: {
		STORAGE_MODE: string;
		STRAPI_API_TOKEN: string;
		STRAPI_API_URL: string;
		STRAPI_ENDPOINT: string;
		TMDB_API_TOKEN: string;
		RECOSERVICIO_SERVERNODERUPA: string;
		autogestion_database_properties_rupabk_jpa_showSql: string;
		ijd_database_testdb_hibernate_use_sql_comments: string;
		webappsiceep_webxml_pathKeystore: string;
		RECOSERVICIO_SERVERNODE: string;
		autogestion_log4j_logspath: string;
		LESSOPEN: string;
		KDE_FULL_SESSION: string;
		sap_database_rupabk_database_username: string;
		autogestion_database_properties_testdb_jpa_showSql: string;
		sap_gdebaclient_properties_gdebaclient_cuilMalvinas: string;
		ijd_gdebaclient_generaciondocumentos_uri: string;
		sap_webxml_maxSessionsUsers: string;
		sap_database_properties_rupabk_connection_acquireIncrement: string;
		LANGUAGE: string;
		webappsiceep_webxml_dbUrlRUPA: string;
		sap_ipscontexto_properties_sap_tag: string;
		sap_ipscontexto_mail_subidaddjjfirmada: string;
		sap_database_testdb_database_username: string;
		sap_webxml_pathKeystore: string;
		RECOSERVICIO_WEBDOC_SERVICIO_PROD: string;
		sap_database_properties_testdb_connection_acquireIncrement: string;
		USER: string;
		mailtask_path: string;
		PAM_KWALLET5_LOGIN: string;
		ijd_gdebaclient_usuario_uri: string;
		autogestion_database_properties_rupabk_connection_checkoutTimeout: string;
		webappsiceep_webxml_dbMinCon: string;
		npm_config_user_agent: string;
		autogestion_gdebaclient_properties_gdebaclient_generartareagedo_uri: string;
		IPS_DATA_SOURCE_RUPA_USER: string;
		XDG_SEAT: string;
		ijd_database_rupabk_database_password: string;
		autogestion_database_properties_testdb_connection_checkoutTimeout: string;
		ijd_gdebaclient_token: string;
		JAVA_TOOL_OPTIONS: string;
		autogestion_gdebaclient_properties_gdebaclient_transaccion_uri: string;
		SSH_AGENT_PID: string;
		webappsiceep_webxml_dbIPSMinCon: string;
		webappsiceep_webxml_dbIPSUrl: string;
		XDG_SESSION_TYPE: string;
		autogestion_webxml_passwdSmtpServerExterno: string;
		GIT_ASKPASS: string;
		autogestion_gdebaclient_properties_gdebaclient_documentosoficiales_uri: string;
		autogestion_recibohaberes_properties_recibohaberes_timeout: string;
		ijd_database_testdb_database_password: string;
		webappsiceep_webxml_dbMaxCon: string;
		ijd_WebFileUtils_host: string;
		npm_node_execpath: string;
		ijd_database_rupabk_database_url: string;
		XCURSOR_SIZE: string;
		sap_gdebaclient_properties_gdebaclient_paseexpediente_uri: string;
		IPS_DATA_SOURCE_RUPA_URL: string;
		SHLVL: string;
		PROBANDO: string;
		npm_config_noproxy: string;
		ijd_database_testdb_database_url: string;
		gid: string;
		autogestion_webxml_maxSessionsUsers: string;
		ANTIGRAVITY_CLI_ALIAS: string;
		HOME: string;
		CHROME_DESKTOP: string;
		sap_ipscontexto_properties_ipscore_tag: string;
		autogestion_database_properties_rupabk_connection_acquireIncrement: string;
		webappsiceep_webxml_dbIPSMaxCon: string;
		sap_glpiclient_properties_glpiclient_token: string;
		webappsiceep_RUPA_DB_PASS: string;
		KDE_APPLICATIONS_AS_SCOPE: string;
		sap_gdebaclient_properties_gdebaclient_generacionexpediente_uri: string;
		TERM_PROGRAM_VERSION: string;
		DESKTOP_SESSION: string;
		sap_clienteeducacion_properties_clienteeducacion_uri: string;
		autogestion_database_properties_testdb_connection_acquireIncrement: string;
		sap_database_properties_rupabk_database_password: string;
		computos_log4j: string;
		sap_gdeba_properties_usuariogdeba_deptonotif_cuil: string;
		NVM_BIN: string;
		npm_package_json: string;
		computos_beans_db_user_ipsol: string;
		NVM_INC: string;
		ijd_database_rupabk_hibernate_show_sql: string;
		sap_database_properties_testdb_database_password: string;
		ijd_gdebaclient_transaccion_uri: string;
		ijd_database_rupabk_connection_minPoolSize: string;
		sap_database_properties_rupabk_database_url: string;
		GTK_RC_FILES: string;
		ijd_gdebaclient_generartareagedo_uri: string;
		XDG_SEAT_PATH: string;
		ijd_database_testdb_hibernate_show_sql: string;
		RECOSERVICIO_DB_PASS: string;
		KDE_SESSION_VERSION: string;
		sap_database_properties_rupabk_hibernate_use_jdbc_metadata_defaults: string;
		sap_gdebaclient_properties_gdebaclient_consultadocumento_uri: string;
		VSCODE_GIT_ASKPASS_MAIN: string;
		ijd_database_testdb_connection_minPoolSize: string;
		ijd_database_rupabk_connection_maxIdleTime: string;
		webappsiceep_webxml_urlHostSAP: string;
		entorno: string;
		VSCODE_GIT_ASKPASS_NODE: string;
		ijd_gdebaclient_documentosoficiales_uri: string;
		git_pass: string;
		MANAGERPID: string;
		autogestion_gdebaclient_properties_gdebaclient_paseexpediente_uri: string;
		uid: string;
		ruta_contexto: string;
		sap_database_properties_testdb_hibernate_use_jdbc_metadata_defaults: string;
		sap_database_properties_testdb_database_url: string;
		npm_config_userconfig: string;
		npm_config_local_prefix: string;
		ijd_database_testdb_connection_maxIdleTime: string;
		SYSTEMD_EXEC_PID: string;
		sap_ipscontexto_properties_ipscontexto_ambiente: string;
		VSCODE_PYTHON_AUTOACTIVATE_GUARD: string;
		webappsiceep_webxml_dbIPSPasswd: string;
		GSM_SKIP_SSH_AGENT_WORKAROUND: string;
		ijd_database_rupabk_connection_maxPoolSize: string;
		ijd_WebFileUtils_protocol: string;
		DBUS_SESSION_BUS_ADDRESS: string;
		npm_config_engine_strict: string;
		COLORTERM: string;
		autogestion_gdeba_properties_usuariogdeba_deptonotif_cuil: string;
		autogestion_database_properties_rupabk_database_password: string;
		ijd_database_testdb_connection_maxPoolSize: string;
		sap_database_properties_rupabk_hibernate_show_sql: string;
		autogestion_gdebaclient_properties_gdebaclient_generacionexpediente_uri: string;
		COLOR: string;
		ijd_database_rupabk_hibernate_format_sql: string;
		sap_database_properties_testdb_hibernate_show_sql: string;
		NVM_DIR: string;
		sap_database_properties_rupabk_connection_minPoolSize: string;
		ijd_encrypted_key: string;
		DEBUGINFOD_URLS: string;
		autogestion_database_properties_testdb_database_password: string;
		ijd_WebFileUtils_pathname: string;
		MANDATORY_PATH: string;
		sap_database_properties_testdb_connection_minPoolSize: string;
		IM_CONFIG_PHASE: string;
		autogestion_gdebaclient_properties_gdebaclient_consultadocumento_uri: string;
		sap_gdebaclient_properties_gdebaclient_cuilRegEspeciales: string;
		webappsiceep_RUPA_DB_USER: string;
		autogestion_database_properties_rupabk_database_url: string;
		ijd_database_testdb_hibernate_format_sql: string;
		sap_database_properties_rupabk_connection_maxIdleTime: string;
		computos_beans_db_user_rupa: string;
		GTK_IM_MODULE: string;
		sap_database_properties_testdb_connection_maxIdleTime: string;
		sap_database_properties_rupabk_connection_maxPoolSize: string;
		LOGNAME: string;
		autogestion_database_properties_testdb_database_url: string;
		computos_beans_db_password_ipsol: string;
		webappsiceep_RUPA_DB_URL: string;
		app_log4j_logspath: string;
		computos_beans_db_minCount_ipsol: string;
		ijd_gdebaclient_paseexpediente_uri: string;
		sap_webxml_isSmtpServerTest: string;
		autogestion_ipscontexto_properties_ipscontexto_ambiente: string;
		sap_database_properties_testdb_connection_maxPoolSize: string;
		QT_AUTO_SCREEN_SCALE_FACTOR: string;
		JOURNAL_STREAM: string;
		_: string;
		npm_config_prefix: string;
		npm_config_npm_version: string;
		autogestion_database_properties_rupabk_hibernate_show_sql: string;
		MEMORY_PRESSURE_WATCH: string;
		sap_database_properties_rupabk_hibernate_format_sql: string;
		ijd_provincia_uri: string;
		XDG_SESSION_CLASS: string;
		computos_beans_db_url_ipsol: string;
		DEFAULTS_PATH: string;
		ijd_log4j_logspath: string;
		RECOSERVICIO_DB_USER: string;
		ijd_gdebaclient_generacionexpediente_uri: string;
		autogestion_database_properties_rupabk_connection_minPoolSize: string;
		sap_database_properties_testdb_hibernate_format_sql: string;
		TERM: string;
		computos_beans_db_maxCount_ipsol: string;
		XDG_SESSION_ID: string;
		autogestion_database_properties_testdb_hibernate_show_sql: string;
		ijd_database_rupabk_connection_breakAfterAcquireFailure: string;
		git_user: string;
		npm_config_cache: string;
		autogestion_database_properties_testdb_connection_minPoolSize: string;
		ijd_database_testdb_connection_breakAfterAcquireFailure: string;
		FC_FONTATIONS: string;
		autogestion_database_properties_rupabk_connection_maxIdleTime: string;
		ijd_gdebaclient_consultadocumento_uri: string;
		sap_clienteeducacion_properties_clienteeducacionperiodo_uri: string;
		GTK2_RC_FILES: string;
		autogestion_database_properties_rupabk_connection_maxPoolSize: string;
		ijd_ipscontexto_webijd_observaciontramite_emp40101_mail: string;
		autogestion_database_properties_testdb_connection_maxIdleTime: string;
		sap_database_rupabk_database_password: string;
		ijd_gdebaclient_cuil_tareafirma: string;
		sap_ipscontexto_properties_mick_tag: string;
		npm_config_node_gyp: string;
		PATH: string;
		SESSION_MANAGER: string;
		ijd_webxml_passwdSmtpServerExterno: string;
		IPS_DATA_SOURCE_PASSWORD: string;
		computos_beans_db_password_rupa: string;
		autogestion_database_properties_testdb_connection_maxPoolSize: string;
		INVOCATION_ID: string;
		sap_database_testdb_database_password: string;
		sap_ipscontexto_properties_gdeba_tag: string;
		autogestion_webxml_isSmtpServerTest: string;
		NODE: string;
		npm_package_name: string;
		ijd_WSResolucionGDEBA_host: string;
		XDG_SESSION_PATH: string;
		ijd_ipscontexto_ambiente: string;
		sap_ipscontexto_properties_ipscontexto_mail: string;
		autogestion_gdebaclient_properties_gdebaclient_cuiltramitesfiscalia: string;
		sap_database_rupabk_database_url: string;
		PATH_WEBAPP_TOMCAT: string;
		computos_beans_db_minCount_rupa: string;
		XDG_RUNTIME_DIR: string;
		XCURSOR_THEME: string;
		GDK_BACKEND: string;
		ICEAUTHORITY: string;
		computos_beans_db_url_rupa: string;
		sap_gdebaclient_properties_gdebaclient_cuilMagisterio: string;
		DISPLAY: string;
		ijd_database_rupabk_database_username: string;
		sap_database_testdb_database_url: string;
		sap_gdebaclient_properties_gdebaclient_consultaexpediente_uri: string;
		computos_beans_db_maxCount_rupa: string;
		RECOSERVICIOS_RUPA_minCount: string;
		LANG: string;
		XDG_CURRENT_DESKTOP: string;
		autogestion_gdeba_properties_usuariogdeba_notificaciones_cuil: string;
		ijd_database_testdb_database_username: string;
		webappsiceep_webxml_dbRUPAPass: string;
		RECOSERVICIOS_IPSOL_minCount: string;
		XMODIFIERS: string;
		XDG_SESSION_DESKTOP: string;
		XAUTHORITY: string;
		IPS_DATA_SOURCE_USER: string;
		LS_COLORS: string;
		VSCODE_GIT_IPC_HANDLE: string;
		TERM_PROGRAM: string;
		npm_lifecycle_script: string;
		SSH_AUTH_SOCK: string;
		RECOSERVICIOS_RUPA_maxCount: string;
		RECOSERVICIO_DB_PASS_RUPA: string;
		autogestion_WebFileUtils_host: string;
		sap_gdebaclient_properties_gdebaclient_cuilMunicipal: string;
		webijd_log4j_logger_org_hibernate_SQL: string;
		SHELL: string;
		sap_webfiles_properties_webfiles_url: string;
		autogestion_ipscontexto_properties_ipscontexto_mail: string;
		sap_gdebaclient_properties_gdebaclient_bloqueoexpediente_uri: string;
		sap_database_properties_rupabk_database_username: string;
		RECOSERVICIO_WEBDOC_SERVICIO: string;
		IPS_DATA_SOURCE_URL: string;
		WEBXML_smtpMailServer: string;
		RECOSERVICIOS_IPSOL_maxCount: string;
		npm_package_version: string;
		npm_lifecycle_event: string;
		QT_ACCESSIBILITY: string;
		sap_ipscontexto_properties_glpi_tag: string;
		sap_database_properties_testdb_database_username: string;
		MI_IPS_IPSCOREAPI_LOGIN: string;
		autogestion_gdebaclient_properties_gdebaclient_cuilMagisterio: string;
		ijd_gdebaclient_cuiltramitesfiscalia: string;
		autogestion_gdebaclient_properties_gdebaclient_consultaexpediente_uri: string;
		ijd_WSResolucionGDEBA_protocol: string;
		LESSCLOSE: string;
		sap_gdebaclient_properties_gdebaclient_generaciondocumentos_uri: string;
		WEBXML_mailFromAdress: string;
		ijd_database_rupabk_jpa_showSql: string;
		sap_gdebaclient_properties_gdebaclient_usuario_uri: string;
		sap_ipscontexto_mail_normativa: string;
		GPG_AGENT_INFO: string;
		webappsiceep_webxml_smtpMailServer: string;
		sap_recibohaberes_properties_recibohaberes_url: string;
		autogestion_gdebaclient_properties_gdebaclient_cuilMunicipal: string;
		sap_gdebaclient_properties_gdebaclient_token: string;
		sap_gdeba_properties_usuariogdeba_rodolfo_cuil: string;
		ijd_encrypted_vector: string;
		ijd_provincia_token: string;
		ijd_database_testdb_jpa_showSql: string;
		ijd_WSResolucionGDEBA_pathname: string;
		ijd_webxml_session_timeout: string;
		sap_gdebaclient_properties_gdebaclient_cuil: string;
		autogestion_database_properties_rupabk_database_username: string;
		webappsiceep_log4j_logspath: string;
		webappsiceep_webxml_dbRUPAUser: string;
		sap_ipscontexto_properties_educacion_tag: string;
		sap_webxml_sessiontimeout: string;
		VSCODE_GIT_ASKPASS_EXTRA_ARGS: string;
		autogestion_gdebaclient_properties_gdebaclient_bloqueoexpediente_uri: string;
		QT_IM_MODULE: string;
		XDG_VTNR: string;
		ijd_database_rupabk_connection_checkoutTimeout: string;
		sap_gdebaclient_properties_gdebaclient_cuilGeneral: string;
		autogestion_webfiles_properties_webfiles_url: string;
		npm_config_globalconfig: string;
		npm_config_init_module: string;
		webappsiceep_webxml_mailFromAdress: string;
		WEBXML_sessionTimeout: string;
		PWD: string;
		ijd_database_testdb_connection_checkoutTimeout: string;
		autogestion_database_properties_testdb_database_username: string;
		ijd_ipscontexto_mail: string;
		autogestion_WebFileUtils_protocol: string;
		npm_execpath: string;
		RECOSERVICIO_DB_USER_RUPA: string;
		sap_database_properties_rupabk_jpa_showSql: string;
		XDG_CONFIG_DIRS: string;
		sap_log4j_logspath: string;
		CLUTTER_IM_MODULE: string;
		webappsiceep_webxml_dbIPSUser: string;
		NVM_CD_FLAGS: string;
		autogestion_gdebaclient_properties_gdebaclient_generaciondocumentos_uri: string;
		XDG_DATA_DIRS: string;
		sap_glpiclient_properties_glpiclient_url: string;
		npm_config_global_prefix: string;
		RECOSERVICIO_SERVERDB: string;
		sap_database_properties_rupabk_connection_maxConnectionAge: string;
		sap_database_properties_testdb_jpa_showSql: string;
		QTWEBENGINE_DICTIONARIES_PATH: string;
		autogestion_gdebaclient_properties_gdebaclient_usuario_uri: string;
		ijd_gdebaclient_consultaexpediente_uri: string;
		RECOSERVICIO_SERVERDBRUPA: string;
		npm_command: string;
		autogestion_WebFileUtils_pathname: string;
		autogestion_gdebaclient_properties_gdebaclient_token: string;
		autogestion_recibohaberes_properties_recibohaberes_url: string;
		sap_database_properties_testdb_connection_maxConnectionAge: string;
		ijd_database_rupabk_connection_acquireIncrement: string;
		KDE_SESSION_UID: string;
		autogestion_gdeba_properties_usuariogdeba_rodolfo_cuil: string;
		RECOSERVICIO_DB_URL_RUPA: string;
		sap_database_properties_rupabk_connection_checkoutTimeout: string;
		sap_gdebaclient_properties_gdebaclient_generartareagedo_uri: string;
		MEMORY_PRESSURE_WRITE: string;
		autogestion_webxml_sessiontimeout: string;
		autogestion_gdebaclient_properties_gdebaclient_cuilGeneral: string;
		sap_gdebaclient_properties_gdebaclient_transaccion_uri: string;
		ijd_database_testdb_connection_acquireIncrement: string;
		sap_database_properties_testdb_connection_checkoutTimeout: string;
		sap_recibohaberes_properties_recibohaberes_timeout: string;
		sap_gdebaclient_properties_gdebaclient_documentosoficiales_uri: string;
		CATALINA_OPTS: string;
		sap_webxml_passwdSmtpServerExterno: string;
		ijd_webxml_isSmtpServerTest: string;
		ijd_gdebaclient_bloqueoexpediente_uri: string;
		ijd_database_rupabk_hibernate_use_sql_comments: string;
		IPS_DATA_SOURCE_RUPA_PASSWORD: string;
		INIT_CWD: string;
		EDITOR: string;
		NODE_ENV: string;
		[key: `PUBLIC_${string}`]: undefined;
		[key: `${string}`]: string | undefined;
	}
}

/**
 * This module provides access to environment variables set _dynamically_ at runtime and that are _publicly_ accessible.
 * 
 * |         | Runtime                                                                    | Build time                                                               |
 * | ------- | -------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
 * | Private | [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private) | [`$env/static/private`](https://svelte.dev/docs/kit/$env-static-private) |
 * | Public  | [`$env/dynamic/public`](https://svelte.dev/docs/kit/$env-dynamic-public)   | [`$env/static/public`](https://svelte.dev/docs/kit/$env-static-public)   |
 * 
 * Dynamic environment variables are defined by the platform you're running on. For example if you're using [`adapter-node`](https://github.com/sveltejs/kit/tree/main/packages/adapter-node) (or running [`vite preview`](https://svelte.dev/docs/kit/cli)), this is equivalent to `process.env`.
 * 
 * **_Public_ access:**
 * 
 * - This module _can_ be imported into client-side code
 * - **Only** variables that begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) (which defaults to `PUBLIC_`) are included
 * 
 * > [!NOTE] In `dev`, `$env/dynamic` includes environment variables from `.env`. In `prod`, this behavior will depend on your adapter.
 * 
 * > [!NOTE] To get correct types, environment variables referenced in your code should be declared (for example in an `.env` file), even if they don't have a value until the app is deployed:
 * >
 * > ```env
 * > MY_FEATURE_FLAG=
 * > ```
 * >
 * > You can override `.env` values from the command line like so:
 * >
 * > ```sh
 * > MY_FEATURE_FLAG="enabled" npm run dev
 * > ```
 * 
 * For example, given the following runtime environment:
 * 
 * ```env
 * ENVIRONMENT=production
 * PUBLIC_BASE_URL=http://example.com
 * ```
 * 
 * With the default `publicPrefix` and `privatePrefix`:
 * 
 * ```ts
 * import { env } from '$env/dynamic/public';
 * console.log(env.ENVIRONMENT); // => undefined, not public
 * console.log(env.PUBLIC_BASE_URL); // => "http://example.com"
 * ```
 * 
 * ```
 * 
 * ```
 */
declare module '$env/dynamic/public' {
	export const env: {
		[key: `PUBLIC_${string}`]: string | undefined;
	}
}
