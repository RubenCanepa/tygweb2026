import { t as storage } from "../../../../chunks/storage.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/peliculas/+server.js
/**
* Handles GET requests to retrieve the entire catalog of movies (city-agnostic)
* from the active storage layer (JSON or Strapi).
*/
async function GET() {
	try {
		return json(await storage.obtenerPeliculas());
	} catch (error) {
		console.error("[api/peliculas] Error interno obteniendo películas:", error);
		return json({
			error: "Error al obtener películas del servidor.",
			details: error.message
		}, { status: 500 });
	}
}
//#endregion
export { GET };
