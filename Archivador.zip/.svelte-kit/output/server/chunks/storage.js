import fs from "fs/promises";
import path from "path";
//#endregion
//#region src/lib/server/jsonStorage.js
var DATA_DIR = path.resolve("data");
var DATA_FILE = path.join(DATA_DIR, "peliculas.json");
/**
* Ensures the data/ directory and data/peliculas.json file exist.
*/
async function ensureFileExists() {
	try {
		await fs.mkdir(DATA_DIR, { recursive: true });
		try {
			await fs.access(DATA_FILE);
		} catch {
			await fs.writeFile(DATA_FILE, JSON.stringify({ data: [] }, null, 2), "utf-8");
		}
	} catch (err) {
		console.error("[jsonStorage] Error inicializando base de datos JSON local:", err);
		throw err;
	}
}
/**
* Read all records from the local JSON file.
*/
async function readAll() {
	await ensureFileExists();
	try {
		const raw = await fs.readFile(DATA_FILE, "utf-8");
		return JSON.parse(raw);
	} catch (err) {
		console.error("[jsonStorage] Error leyendo JSON local:", err);
		return { data: [] };
	}
}
/**
* Write records back to the local JSON file.
*/
async function writeAll(dataEnvelope) {
	await ensureFileExists();
	try {
		await fs.writeFile(DATA_FILE, JSON.stringify(dataEnvelope, null, 2), "utf-8");
	} catch (err) {
		console.error("[jsonStorage] Error escribiendo en JSON local:", err);
		throw err;
	}
}
var jsonStorage = {
	/**
	* Retrieves the entire collection of movies
	* @returns {Promise<{ data: Array }>}
	*/
	async obtenerPeliculas() {
		return await readAll();
	},
	/**
	* Empties the database and saves the new movie list
	* @param {Array<object>} peliculas - The new batch of movie fields
	* @returns {Promise<{ data: Array }>} - The saved list wrapped in a Strapi response envelope
	*/
	async reemplazarPeliculas(peliculas) {
		const envelope = { data: peliculas.map((movie, index) => {
			return {
				id: index + 1,
				attributes: {
					title: movie.title,
					overview: movie.overview,
					poster_path: movie.poster_path,
					vote_average: Number(movie.vote_average) || 0,
					release_date: movie.release_date,
					tmdb_id: Number(movie.tmdb_id)
				}
			};
		}) };
		await writeAll(envelope);
		console.log(`[jsonStorage] Catálogo reemplazado por completo con ${peliculas.length} películas.`);
		return envelope;
	}
};
//#endregion
//#region src/lib/server/strapiStorage.js
var apiPath = `http://localhost:1337/api/canepa-peliculas`;
/**
* Generates headers for API requests to Strapi
*/
function getHeaders() {
	return {
		"Content-Type": "application/json",
		Accept: "application/json"
	};
}
var strapiStorage = {
	/**
	* Fetches the entire collection of movies from Strapi (city-agnostic)
	* @returns {Promise<{ data: Array }>}
	*/
	async obtenerPeliculas() {
		const queryUrl = `${apiPath}?pagination[limit]=100`;
		console.log(`[strapiStorage] Obteniendo listado completo desde: ${queryUrl}`);
		const res = await fetch(queryUrl, {
			method: "GET",
			headers: getHeaders()
		});
		if (!res.ok) throw new Error(`Error en Strapi GET: ${res.status} ${res.statusText}`);
		return await res.json();
	},
	/**
	* Deletes all existing records and uploads the new batch
	* @param {Array<object>} peliculas - New movies collection
	* @returns {Promise<{ data: Array }>}
	*/
	async reemplazarPeliculas(peliculas) {
		const headers = getHeaders();
		console.log(`[strapiStorage] Obteniendo películas existentes para borrar...`);
		const currentRes = await fetch(`${apiPath}?pagination[limit]=150`, {
			method: "GET",
			headers
		});
		if (!currentRes.ok) throw new Error(`Error al recuperar lista previa de Strapi: ${currentRes.status}`);
		const oldRecords = (await currentRes.json()).data || [];
		console.log(`[strapiStorage] Borrando ${oldRecords.length} películas anteriores...`);
		for (const record of oldRecords) {
			const deleteUrl = `${apiPath}/${record.id}`;
			try {
				const delRes = await fetch(deleteUrl, {
					method: "DELETE",
					headers
				});
				if (!delRes.ok) console.warn(`No se pudo eliminar el registro ID ${record.id} de Strapi. Código: ${delRes.status}`);
			} catch (err) {
				console.error(`Error borrando ID ${record.id}:`, err);
			}
		}
		console.log(`[strapiStorage] Subiendo ${peliculas.length} películas nuevas...`);
		const uploadedList = [];
		for (const movie of peliculas) {
			const payload = {
				title: movie.title,
				overview: movie.overview || "",
				poster_path: movie.poster_path,
				vote_average: Number(movie.vote_average) || 0,
				release_date: movie.release_date || null,
				tmdb_id: Number(movie.tmdb_id)
			};
			try {
				const createRes = await fetch(apiPath, {
					method: "POST",
					headers,
					body: JSON.stringify({ data: payload })
				});
				if (!createRes.ok) throw new Error(`Fallo al crear registro en Strapi. Código: ${createRes.status}`);
				const resObj = await createRes.json();
				if (resObj.data) uploadedList.push(resObj.data);
			} catch (err) {
				console.error(`Error insertando película "${movie.title}" en Strapi:`, err);
			}
		}
		console.log(`[strapiStorage] Proceso completado. Se subieron ${uploadedList.length} registros a Strapi.`);
		return { data: uploadedList };
	}
};
//#endregion
//#region src/lib/server/storage.js
var mode = "json".toLowerCase().trim();
console.log(`[Storage] Inicializando sistema de persistencia en modo: "${mode}"`);
var storage = mode === "strapi" ? strapiStorage : jsonStorage;
var storageMode = mode;
//#endregion
export { storageMode as n, storage as t };
