import "../../../../chunks/storage.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/generar/+server.js
/**
* Handles POST requests to fetch a specific number of movies (20, 40, or 60)
* from TMDB by navigating through its pages and replacing the entire active storage.
*/
async function POST({ request }) {
	try {
		const { cantidad } = await request.json();
		const numCantidad = Number(cantidad) || 20;
		if (![
			20,
			40,
			60
		].includes(numCantidad)) return json({ error: "La cantidad seleccionada debe ser 20, 40 o 60." }, { status: 400 });
		return json({ error: "El token TMDB_API_TOKEN no está configurado en el servidor." }, { status: 500 });
	} catch (error) {
		console.error("[generar] Error interno en endpoint:", error);
		return json({
			error: "Error interno en el servidor.",
			details: error.message
		}, { status: 500 });
	}
}
//#endregion
export { POST };
