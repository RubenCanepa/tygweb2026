export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["robots.txt"]),
	mimeTypes: {".txt":"text/plain"},
	_: {
		client: {start:"_app/immutable/entry/start.DCQ4RwFD.js",app:"_app/immutable/entry/app.CETdZKJs.js",imports:["_app/immutable/entry/start.DCQ4RwFD.js","_app/immutable/chunks/BuqP4bnU.js","_app/immutable/chunks/H3HEyhsf.js","_app/immutable/entry/app.CETdZKJs.js","_app/immutable/chunks/H3HEyhsf.js","_app/immutable/chunks/DYl5dUZ5.js","_app/immutable/chunks/xihTtKlq.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/api/generar",
				pattern: /^\/api\/generar\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/generar/_server.js'))
			},
			{
				id: "/api/peliculas",
				pattern: /^\/api\/peliculas\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/peliculas/_server.js'))
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
