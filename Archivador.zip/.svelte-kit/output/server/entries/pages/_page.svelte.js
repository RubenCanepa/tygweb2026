import { n as onDestroy } from "../../chunks/index-server.js";
import { b as escape_html, i as ensure_array_like, n as attr_style, o as stringify, r as derived, t as attr_class, y as attr } from "../../chunks/server.js";
import "chart.js/auto";
//#region src/lib/ciudades.js
var CIUDADES = [
	"Buenos Aires",
	"La Plata",
	"9 de Julio"
];
/**
* Pure function to check if a movie belongs to a city based on mathematical rules on its tmdb_id.
* - Buenos Aires: all movies
* - La Plata: only even tmdb_ids
* - 9 de Julio: tmdb_ids divisible by 5
* 
* @param {number} tmdb_id 
* @param {string} ciudad 
* @returns {boolean}
*/
function perteneceACiudad(tmdb_id, ciudad) {
	const numericId = Number(tmdb_id);
	if (isNaN(numericId)) return false;
	switch (ciudad) {
		case "Buenos Aires": return true;
		case "La Plata": return numericId % 2 === 0;
		case "9 de Julio": return numericId % 5 === 0;
		default: return false;
	}
}
//#endregion
//#region src/routes/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let ciudadSeleccionada = "Buenos Aires";
		let cantidadSeleccionada = 20;
		let allMovies = [];
		let loading = false;
		let status = {
			type: "",
			message: ""
		};
		let movies = derived(() => allMovies.filter((m) => perteneceACiudad(Number(m.tmdb_id), ciudadSeleccionada)));
		let averageRating = derived(() => movies().length > 0 ? (movies().reduce((sum, m) => sum + Number(m.vote_average), 0) / movies().length).toFixed(2) : "0.00");
		let movieCount = derived(() => movies().length);
		onDestroy(() => {});
		$$renderer.push(`<div class="app-container"><header class="app-header"><h1 class="app-title-gradient">TP Nro 2 - Grupo Canepa</h1> <span class="app-group-badge" id="group-badge">TygWeb UTN FRLP</span></header> <div class="main-layout"><aside class="app-sidebar"><div class="sidebar-section"><label class="sidebar-label" for="city-select">Ciudad a simular</label> `);
		$$renderer.select({
			id: "city-select",
			class: "input-field",
			style: "background-color: #0b0f19; cursor: pointer;",
			value: ciudadSeleccionada,
			disabled: loading
		}, ($$renderer) => {
			$$renderer.push(`<!--[-->`);
			const each_array = ensure_array_like(CIUDADES);
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let c = each_array[$$index];
				$$renderer.option({
					value: c,
					style: "background-color: #0f172a; color: #f8fafc;"
				}, ($$renderer) => {
					$$renderer.push(`${escape_html(c)}`);
				});
			}
			$$renderer.push(`<!--]-->`);
		});
		$$renderer.push(`</div> <div class="sidebar-section"><label class="sidebar-label" for="quantity-select">Cantidad a cargar</label> `);
		$$renderer.select({
			id: "quantity-select",
			class: "input-field",
			style: "background-color: #0b0f19; cursor: pointer;",
			value: cantidadSeleccionada,
			disabled: loading
		}, ($$renderer) => {
			$$renderer.option({
				value: 20,
				style: "background-color: #0f172a; color: #f8fafc;"
			}, ($$renderer) => {
				$$renderer.push(`20 películas`);
			});
			$$renderer.option({
				value: 40,
				style: "background-color: #0f172a; color: #f8fafc;"
			}, ($$renderer) => {
				$$renderer.push(`40 películas`);
			});
			$$renderer.option({
				value: 60,
				style: "background-color: #0f172a; color: #f8fafc;"
			}, ($$renderer) => {
				$$renderer.push(`60 películas`);
			});
		});
		$$renderer.push(`</div> <div class="sidebar-section"><button id="btn-cargar" class="btn btn-primary"${attr("disabled", loading, true)}>`);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`Cargar datos de APIs`);
		$$renderer.push(`<!--]--></button> <button id="btn-visualizar" class="btn btn-secondary"${attr("disabled", loading, true)}>Visualizar datos</button></div> `);
		if (status.message) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div${attr_class(`status-container status-${stringify(status.type)}`)} id="status-box"><span>${escape_html(status.message)}</span></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></aside> <main class="main-content">`);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="metrics-row"><div class="metric-card glass-panel"><span class="metric-title">Ciudad Simulada</span> <span class="metric-value" id="metric-city">${escape_html(ciudadSeleccionada)}</span></div> <div class="metric-card glass-panel"><span class="metric-title">Rating Promedio</span> <span class="metric-value" id="metric-avg-rating">${escape_html(averageRating())} / 10</span></div> <div class="metric-card glass-panel"><span class="metric-title">Películas Filtradas</span> <span class="metric-value" id="metric-count">${escape_html(movieCount())}</span></div></div> <div class="chart-container glass-panel"><h2 class="chart-title">Ratings por Película (${escape_html(ciudadSeleccionada)})</h2> `);
		if (movies().length === 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div style="flex: 1; display: flex; align-items: center; justify-content: center; color: var(--text-muted); font-size: 0.95rem; text-align: center; padding: 1rem;">No hay películas que cumplan la condición para "${escape_html(ciudadSeleccionada)}" en el catálogo.<br/> Hacé clic en "Cargar datos de APIs" para sincronizar el catálogo.</div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div${attr_style(`position: relative; flex: 1; min-height: 250px; display: ${movies().length === 0 ? "none" : "block"};`)}><canvas id="rating-chart"></canvas></div></div> <section aria-labelledby="movies-section-title"><h2 id="movies-section-title" style="margin-bottom: 1.5rem; font-size: 1.5rem; font-family: 'Outfit', sans-serif;">Películas en Cartelera</h2> `);
		if (movies().length === 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="glass-panel" style="padding: 3rem; text-align: center; color: var(--text-secondary);">No hay películas cargadas para mostrar en esta sección bajo la regla de "${escape_html(ciudadSeleccionada)}".</div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="movies-grid"><!--[-->`);
			const each_array_1 = ensure_array_like(movies());
			for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
				let movie = each_array_1[$$index_1];
				$$renderer.push(`<article class="movie-card glass-panel"><div class="movie-poster-container">`);
				if (movie.poster_path) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<img${attr("src", movie.poster_path)}${attr("alt", `Poster de ${stringify(movie.title)}`)} class="movie-poster" loading="lazy"/>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<div style="height: 100%; display: flex; align-items: center; justify-content: center; background: #121824; color: var(--text-muted); font-size: 0.85rem;">Sin Póster</div>`);
				}
				$$renderer.push(`<!--]--> <span class="movie-rating-badge">★ ${escape_html(Number(movie.vote_average).toFixed(1))}</span></div> <div class="movie-info"><h3 class="movie-title"${attr("title", movie.title)}>${escape_html(movie.title)}</h3> <p class="movie-date">Estreno: ${escape_html(movie.release_date || "N/D")} | ID: ${escape_html(movie.tmdb_id)}</p> <p class="movie-overview"${attr("title", movie.overview)}>${escape_html(movie.overview || "Sin descripción disponible.")}</p></div></article>`);
			}
			$$renderer.push(`<!--]--></div>`);
		}
		$$renderer.push(`<!--]--></section></main></div> <footer class="app-footer"><p>TygWeb 2026 - Tecnología y Gestión Web (UTN FRLP)</p></footer></div>`);
	});
}
//#endregion
export { _page as default };
